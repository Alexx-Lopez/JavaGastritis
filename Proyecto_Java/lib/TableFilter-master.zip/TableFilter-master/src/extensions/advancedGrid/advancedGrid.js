import AdapterEzEditTable from './adapterEzEditTable';

export default AdapterEzEditTable;